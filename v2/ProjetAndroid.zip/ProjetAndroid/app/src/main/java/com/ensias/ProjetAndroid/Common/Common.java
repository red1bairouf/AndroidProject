package com.ensias.ProjetAndroid.Common;

import com.ensias.ProjetAndroid.Model.User;

public class Common {
    public static User currentUser ;
}
